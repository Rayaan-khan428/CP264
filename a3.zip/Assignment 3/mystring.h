#ifndef MYSTRING_H
#define MYSTRING_H

int str_len(char *);
int str_wc(char *);
void str_lower(char *);
void str_trim(char *);

#endif