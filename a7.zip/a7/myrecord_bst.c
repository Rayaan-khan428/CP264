/*
 * your program signature
 */ 
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "queue_stack.h"
#include "bst.h"
#include "myrecord_bst.h"

void add_data(TREE *tree, char *name, float score) {
     
    // i dont understand this man

}

void remove_data(TREE *tree, char *name) {


}