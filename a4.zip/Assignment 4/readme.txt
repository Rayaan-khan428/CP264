JobID: cp264oc-a4-lab4
Name: rayaan khan   
ID: 210650310

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab4

T1 Induction proof
T1.1 [2/2/*] Write induction proof           

T2 Big-O notation
T2.1 [2/2/*] Prove Big-O statements          

T3 Build tool for complex C programs
T3.1 [0/0/*] Build all by one command        
T3.2 [0/0/*] Build incrementally             
T3.3 [1/1/*] Build static library            
T3.4 [2/2/*] Build using make                

T4 Sorting algorithms and analysis
T4.1 [2/2/*] Read and test sorting examples  
T4.2 [1/1/*] Merge sorting complexity proof  

A4

Q1 Sorting algorithms
Q1.1 [6/6/*] select_sort()                           
Q1.2 [6/6/*] quick_sort()                            

Q2 Record data processing
Q2.1 [1/1/*] RECORD type                             
Q2.2 [1/1/*] STATS type                              
Q2.3 [1/1/*] GRADE type                              
Q2.4 [3/3/*] grade()                                 
Q2.5 [3/3/*] import_data()                           
Q2.6 [5/6/*] process_data()                          
Q2.7 [1/3/*] report_data()                           

Total: [33/40/*]


