/*
 * your program signature
 */ 

#ifndef MYSORT_H
#define MYSORT_H 

void select_sort(float *a[], int left, int right);
void quick_sort(float *a[], int left, int right);

#endif