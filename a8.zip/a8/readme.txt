JobID: cp264oc-a8-lab8
Name: Rayaan Khan
ID: 210650310

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

Lab8

T1 BST
T1.1 [2/2/*] Read and test BST example

T2 AVL trees
T2.1 [4/4/*] Read and test AVL examples

T3 Red-Black-tree
T3.1 [2/2/*] Read and test Red-Black-tree

T4 Splay trees
T4.1 [2/2/*] Read and test Splay tree

A8

Q1 AVL tree
Q1.1 [4/4/*] balance_factor(),is_avl()               
Q1.2 [3/3/*] rotate_left()                           
Q1.3 [3/3/*] rotate_right()                          
Q1.4 [5/5/*] insert()                                
Q1.5 [5/5/*] delete()                                

Q2 AVL tree for record data processing
Q2.1 [5/5/*] merge_tree()                            
Q2.2 [5/5/*] merge_data()                            

Total: [40/40/*]


